

<?php $__env->startSection('page-title', 'Edit Evaluation Report'); ?>
<?php $__env->startSection('page-description', 'Edit comprehensive evaluation report for employees'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="content-wrapper">
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul class="mb-0">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <?php if(session('error')): ?>
                <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
            <?php endif; ?>

            <?php if(session('success')): ?>
                <div class="alert alert-success"><?php echo e(session('success')); ?></div>
            <?php endif; ?>

            <div class="page-header">
                <h2>Edit Evaluation Report</h2>
                <p>Edit performance evaluation for <strong><?php echo e($report->employee->name); ?></strong></p>
            </div>

            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h5 class="card-title">Development Team - Performance Evaluation Form</h5>
                            <a href="<?php echo e(route('admin.evaluation-report')); ?>" class="btn btn-secondary btn-sm">
                                Back to Reports
                            </a>
                        </div>
                        <div class="card-body">
                            <div class="evaluation-form">
                                <form id="performanceForm" action="<?php echo e(route('admin.update-evaluation-report', $report->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>

                                    <?php
                                        $admin = auth('admin')->user();
                                        $isSuperAdmin = $admin->role === 'super_admin';
                                        $isStep1Assigned = false;
                                        $isStep2Assigned = false;

                                        if (!$isSuperAdmin) {
                                            $step1Assignments = \App\Models\EvaluationAssignment::where('step', 'step1')->first();
                                            $step2Assignments = \App\Models\EvaluationAssignment::where('step', 'step2')->first();
                                            $isStep1Assigned = $step1Assignments && in_array($admin->id, $step1Assignments->assigned_admins ?? []);
                                            $isStep2Assigned = $step2Assignments && in_array($admin->id, $step2Assignments->assigned_admins ?? []);
                                        }

                                        $manager = $report->evaluationManager;
                                        $hr = $report->evaluationHr;
                                        $overall = $report->evaluationOverall;
                                    ?>

                                    <!-- Employee Details (Read-only in edit) -->
                                    <div class="form-section employee-details">
                                        <h3>Employee Details</h3>
                                        <div class="grid">
                                            <div>
                                                <label>Employee</label>
                                                <input type="text" value="<?php echo e($report->employee->name); ?> (<?php echo e($report->employee->employee_code); ?>)" readonly>
                                                <input type="hidden" name="employee_id" value="<?php echo e($report->employee_id); ?>">
                                                <input type="hidden" name="employee_name" value="<?php echo e($report->employee->employee_code); ?> - <?php echo e($report->employee->name); ?>">
                                            </div>
                                            <div>
                                                <label>Review Period</label>
                                                <input type="text" value="<?php echo e($report->review_from->format('M d, Y')); ?> - <?php echo e($report->review_to->format('M d, Y')); ?>" readonly>
                                                <input type="hidden" name="review_from" value="<?php echo e($report->review_from); ?>">
                                                <input type="hidden" name="review_to" value="<?php echo e($report->review_to); ?>">
                                            </div>
                                            <div>
                                                <label>Date of Evaluation</label>
                                                <input type="date" name="evaluation_date" value="<?php echo e($report->evaluation_date->format('Y-m-d')); ?>" required>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Part 1: Manager Evaluation -->
                                    <?php if($isSuperAdmin || $isStep1Assigned): ?>
                                    <div class="form-section manager-evaluation">
                                        <div class="section-header">
                                            <h3>Part 1: Manager Evaluation</h3>
                                            <span class="section-badge manager-badge">Technical Assessment</span>
                                        </div>

                                        <div class="subsection">
                                            <h4>1.1 Key Performance Indicators (KPIs)</h4>
                                            <label>Project Delivery & Updates</label>
                                            <input type="text" name="project_delivery" class="form-control"
                                                   value="<?php echo e($manager?->project_delivery ?? ''); ?>">

                                            <label>Code Quality & Standards</label>
                                            <input type="text" name="code_quality" class="form-control"
                                                   value="<?php echo e($manager?->code_quality ?? ''); ?>">

                                            <label>System/Application Performance</label>
                                            <input type="text" name="performance" class="form-control"
                                                   value="<?php echo e($manager?->performance ?? ''); ?>">

                                            <label>Task Completion & Accuracy</label>
                                            <input type="text" name="task_completion" class="form-control"
                                                   value="<?php echo e($manager?->task_completion ?? ''); ?>">

                                            <label>Innovation & Problem Solving</label>
                                            <input type="text" name="innovation" class="form-control"
                                                   value="<?php echo e($manager?->innovation ?? ''); ?>">
                                        </div>

                                        <div class="subsection">
                                            <h4>1.2 Technical Skills Assessment</h4>
                                            <div class="grid">
                                                <div>
                                                    <label>Code/Task Efficiency (1–5)</label>
                                                    <div class="rating">
                                                        <?php for($i = 5; $i >= 1; $i--): ?>
                                                            <input type="radio" name="code_efficiency" id="ce<?php echo e($i); ?>" value="<?php echo e($i); ?>"
                                                                   <?php echo e($manager?->code_efficiency == $i ? 'checked' : ''); ?>>
                                                            <label for="ce<?php echo e($i); ?>"></label>
                                                        <?php endfor; ?>
                                                    </div>
                                                </div>
                                                <div>
                                                    <label>UI/UX Implementation (1–5)</label>
                                                    <div class="rating">
                                                        <?php for($i = 5; $i >= 1; $i--): ?>
                                                            <input type="radio" name="uiux" id="ui<?php echo e($i); ?>" value="<?php echo e($i); ?>"
                                                                   <?php echo e($manager?->uiux == $i ? 'checked' : ''); ?>>
                                                            <label for="ui<?php echo e($i); ?>"></label>
                                                        <?php endfor; ?>
                                                    </div>
                                                </div>
                                                <div>
                                                    <label>Debugging & Testing Skills (1–5)</label>
                                                    <div class="rating">
                                                        <?php for($i = 5; $i >= 1; $i--): ?>
                                                            <input type="radio" name="debugging" id="db<?php echo e($i); ?>" value="<?php echo e($i); ?>"
                                                                   <?php echo e($manager?->debugging == $i ? 'checked' : ''); ?>>
                                                            <label for="db<?php echo e($i); ?>"></label>
                                                        <?php endfor; ?>
                                                    </div>
                                                </div>
                                                <div>
                                                    <label>Version Control Usage (1–5)</label>
                                                    <div class="rating">
                                                        <?php for($i = 5; $i >= 1; $i--): ?>
                                                            <input type="radio" name="version_control" id="vc<?php echo e($i); ?>" value="<?php echo e($i); ?>"
                                                                   <?php echo e($manager?->version_control == $i ? 'checked' : ''); ?>>
                                                            <label for="vc<?php echo e($i); ?>"></label>
                                                        <?php endfor; ?>
                                                    </div>
                                                </div>
                                                <div>
                                                    <label>Documentation Quality (1–5)</label>
                                                    <div class="rating">
                                                        <?php for($i = 5; $i >= 1; $i--): ?>
                                                            <input type="radio" name="documentation" id="doc<?php echo e($i); ?>" value="<?php echo e($i); ?>"
                                                                   <?php echo e($manager?->documentation == $i ? 'checked' : ''); ?>>
                                                            <label for="doc<?php echo e($i); ?>"></label>
                                                        <?php endfor; ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="subsection">
                                            <h4>1.3 Manager Comments</h4>
                                            <textarea name="manager_comments" placeholder="Technical feedback..."><?php echo e($manager?->manager_comments ?? ''); ?></textarea>
                                        </div>
                                    </div>
                                    <?php endif; ?>

                                    <!-- Part 2: HR Evaluation -->
                                    <?php if($isSuperAdmin || $isStep2Assigned): ?>
                                    <div class="form-section hr-evaluation">
                                        <div class="section-header">
                                            <h3>Part 2: HR Evaluation</h3>
                                            <span class="section-badge hr-badge">Behavioral Assessment</span>
                                        </div>

                                        <div class="subsection">
                                            <h4>2.1 Behavioral & Soft Skills</h4>
                                            <label>Collaboration & Teamwork</label>
                                            <input type="text" name="teamwork" class="form-control"
                                                   value="<?php echo e($hr?->teamwork ?? ''); ?>">

                                            <label>Communication & Reporting</label>
                                            <input type="text" name="communication" class="form-control"
                                                   value="<?php echo e($hr?->communication ?? ''); ?>">

                                            <label>Attendance & Punctuality</label>
                                            <input type="text" name="attendance" class="form-control"
                                                   value="<?php echo e($hr?->attendance ?? ''); ?>">
                                        </div>

                                        <div class="subsection">
                                            <h4>2.2 Soft Skills Ratings</h4>
                                            <div class="grid">
                                                <div>
                                                    <label>Professionalism (1–5)</label>
                                                    <div class="rating">
                                                        <?php for($i = 5; $i >= 1; $i--): ?>
                                                            <input type="radio" name="professionalism" id="pr<?php echo e($i); ?>" value="<?php echo e($i); ?>"
                                                                   <?php echo e($hr?->professionalism == $i ? 'checked' : ''); ?>>
                                                            <label for="pr<?php echo e($i); ?>"></label>
                                                        <?php endfor; ?>
                                                    </div>
                                                </div>
                                                <div>
                                                    <label>Team Collaboration (1–5)</label>
                                                    <div class="rating">
                                                        <?php for($i = 5; $i >= 1; $i--): ?>
                                                            <input type="radio" name="team_collaboration" id="tc<?php echo e($i); ?>" value="<?php echo e($i); ?>"
                                                                   <?php echo e($hr?->team_collaboration == $i ? 'checked' : ''); ?>>
                                                            <label for="tc<?php echo e($i); ?>"></label>
                                                        <?php endfor; ?>
                                                    </div>
                                                </div>
                                                <div>
                                                    <label>Learning & Adaptability (1–5)</label>
                                                    <div class="rating">
                                                        <?php for($i = 5; $i >= 1; $i--): ?>
                                                            <input type="radio" name="learning" id="la<?php echo e($i); ?>" value="<?php echo e($i); ?>"
                                                                   <?php echo e($hr?->learning == $i ? 'checked' : ''); ?>>
                                                            <label for="la<?php echo e($i); ?>"></label>
                                                        <?php endfor; ?>
                                                    </div>
                                                </div>
                                                <div>
                                                    <label>Initiative & Ownership (1–5)</label>
                                                    <div class="rating">
                                                        <?php for($i = 5; $i >= 1; $i--): ?>
                                                            <input type="radio" name="initiative" id="io<?php echo e($i); ?>" value="<?php echo e($i); ?>"
                                                                   <?php echo e($hr?->initiative == $i ? 'checked' : ''); ?>>
                                                            <label for="io<?php echo e($i); ?>"></label>
                                                        <?php endfor; ?>
                                                    </div>
                                                </div>
                                                <div>
                                                    <label>Time Management (1–5)</label>
                                                    <div class="rating">
                                                        <?php for($i = 5; $i >= 1; $i--): ?>
                                                            <input type="radio" name="time_management" id="tm<?php echo e($i); ?>" value="<?php echo e($i); ?>"
                                                                   <?php echo e($hr?->time_management == $i ? 'checked' : ''); ?>>
                                                            <label for="tm<?php echo e($i); ?>"></label>
                                                        <?php endfor; ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="subsection">
                                            <h4>2.3 HR Comments</h4>
                                            <textarea name="hr_comments" placeholder="Behavioral feedback..."><?php echo e($hr?->hr_comments ?? ''); ?></textarea>
                                        </div>
                                    </div>
                                    <?php endif; ?>

                                    <!-- Part 3: Overall Evaluation (Super Admin Only) -->
                                    <?php if($isSuperAdmin): ?>
                                  <div class="form-section overall-evaluation">
    <div class="section-header">
        <h3>Part 3: Overall Evaluation</h3>
        <span class="section-badge overall-badge">Final Assessment</span>
    </div>

    <div class="subsection">
        <h4>3.1 Performance Scoring</h4>
        <div class="grid">

            <div>
                <label>Skills</label>
                <input type="range" name="technical_skills" min="0" max="10"
                       value="<?php echo e($overall?->technical_skills ?? 0); ?>" class="score-slider" data-max="10">
                <span class="score-display">0 / 10</span>
            </div>

            <div>
                <label>Task Delivery</label>
                <input type="range" name="task_delivery_score" min="0" max="10"
                       value="<?php echo e($overall?->task_delivery ?? 0); ?>" class="score-slider" data-max="10">
                <span class="score-display">0 / 10</span>
            </div>

            <div>
                <label>Quality of Work</label>
                <input type="range" name="quality_work" min="0" max="10"
                       value="<?php echo e($overall?->quality_work ?? 0); ?>" class="score-slider" data-max="10">
                <span class="score-display">0 / 10</span>
            </div>

            <div>
                <label>Communication</label>
                <input type="range" name="communication_score" min="0" max="10"
                       value="<?php echo e($overall?->communication ?? 0); ?>" class="score-slider" data-max="10">
                <span class="score-display">0 / 10</span>
            </div>

            <div>
                <label>Behavior & Teamwork</label>
                <input type="range" name="behavior_teamwork" min="0" max="10"
                       value="<?php echo e($overall?->behavior_teamwork ?? 0); ?>" class="score-slider" data-max="10">
                <span class="score-display">0 / 10</span>
            </div>

            <input type="hidden" name="overall_rating" value="<?php echo e($overall?->overall_rating ?? 0); ?>">
        </div>
    </div>

    <div class="subsection">
        <h4>3.2 Final Assessment</h4>

        <label>Performance Grade</label>
        <select name="performance_grade" required>
            <option value="">Select Grade</option>
            <option value="Excellent" <?php echo e($overall?->performance_grade == 'Excellent' ? 'selected' : ''); ?>>Excellent</option>
            <option value="Good" <?php echo e($overall?->performance_grade == 'Good' ? 'selected' : ''); ?>>Good</option>
            <option value="Satisfactory" <?php echo e($overall?->performance_grade == 'Satisfactory' ? 'selected' : ''); ?>>Satisfactory</option>
            <option value="Needs Improvement" <?php echo e($overall?->performance_grade == 'Needs Improvement' ? 'selected' : ''); ?>>Needs Improvement</option>
        </select>

        <label>Final Feedback</label>
        <textarea name="final_feedback" placeholder="Overall summary, strengths, improvement areas..."><?php echo e($overall?->final_feedback ?? ''); ?></textarea>
    </div>
</div>

                                    <?php endif; ?>

                                    <button type="submit">Update Evaluation Report</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.querySelectorAll('.score-slider').forEach(function(slider) {

    function updateScore(slider) {
        let value = slider.value;
        let max = slider.getAttribute('max');
        let display = slider.parentElement.querySelector('.score-display');

        if (display) {
            display.textContent = value + " / " + max;
        }

        calculateOverall(); // update overall score
    }

    slider.addEventListener('input', function() {
        updateScore(slider);
    });

    // initialize on page load
    updateScore(slider);
});

function calculateOverall() {
    let t = parseInt(document.querySelector('[name="technical_skills"]').value || 0);
    let d = parseInt(document.querySelector('[name="task_delivery_score"]').value || 0);
    let q = parseInt(document.querySelector('[name="quality_work"]').value || 0);
    let c = parseInt(document.querySelector('[name="communication_score"]').value || 0);
    let b = parseInt(document.querySelector('[name="behavior_teamwork"]').value || 0);

    let total = t + d + q + c + b; // 0–50

    document.querySelector('[name="overall_rating"]').value = total;
}
</script>


<style>
.evaluation-form form {
    background: linear-gradient(135deg, rgba(99, 102, 241, 0.05), rgba(168, 85, 247, 0.05));
    backdrop-filter: blur(10px);
    padding: 35px 40px;
    border-radius: 20px;
    box-shadow: 0 10px 30px rgba(79, 70, 229, 0.15);
    max-width: 1100px;
    margin: auto;
    border-top: 5px solid #818cf8;
    border-left: 5px solid #818cf8;
}

.evaluation-form h3 {
    color: #818cf8;
    margin-top: 30px;
    border-left: 5px solid #818cf8;
    padding-left: 12px;
    font-size: 21px;
    font-weight: 600;
}

.evaluation-form h4 {
    color: #6366f1;
    margin-top: 20px;
    font-size: 16px;
    font-weight: 600;
}

.evaluation-form label {
    font-weight: 600;
    color: #818cf8;
    margin-bottom: 8px;
    display: block;
    font-size: 15px;
}

.evaluation-form input,
.evaluation-form select,
.evaluation-form textarea {
    width: 100%;
    padding: 12px 14px;
    border: 1.5px solid #c7d2fe;
    border-radius: 12px;
    font-size: 14px;
    background: #fafaff;
    color: #1e293b;
    transition: all 0.3s ease;
}

.evaluation-form input::placeholder,
.evaluation-form textarea::placeholder {
    color: #94a3b8;
}

.evaluation-form input:focus,
.evaluation-form select:focus,
.evaluation-form textarea:focus {
    border-color: #6366f1;
    box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.2);
    outline: none;
    background: #fff;
}

.evaluation-form textarea {
    resize: vertical;
    min-height: 100px;
}

.evaluation-form button {
    background: linear-gradient(135deg, #6366f1a1, #6366f1);
    color: #fff;
    border: none;
    padding: 16px 25px;
    border-radius: 14px;
    margin-top: 30px;
    cursor: pointer;
    font-size: 17px;
    font-weight: 600;
    display: block;
    width: 100%;
    box-shadow: 0 6px 20px rgba(99, 102, 241, 0.3);
    transition: all 0.3s ease;
}

.evaluation-form button:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 25px rgba(99, 102, 241, 0.4);
}

.evaluation-form .form-section {
    margin-bottom: 40px;
    padding: 25px;
    background: rgba(255, 255, 255, 0.8);
    border-radius: 15px;
    border: 1px solid rgba(99, 102, 241, 0.1);
}

.evaluation-form .section-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
    padding-bottom: 15px;
    border-bottom: 2px solid #e0e7ff;
}

.evaluation-form .section-badge {
    padding: 5px 12px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: 600;
    text-transform: uppercase;
}

.evaluation-form .manager-badge { background: linear-gradient(135deg, #10b981, #059669); color: white; }
.evaluation-form .hr-badge { background: linear-gradient(135deg, #f59e0b, #d97706); color: white; }
.evaluation-form .overall-badge { background: linear-gradient(135deg, #8b5cf6, #7c3aed); color: white; }

.evaluation-form .subsection { margin-bottom: 25px; }
.evaluation-form .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 22px; margin-top: 10px; }

/* Star Rating */
.evaluation-form .rating { display: flex; flex-direction: row-reverse; justify-content: flex-end; gap: 6px; margin-top: 8px; }
.evaluation-form .rating input { display: none; }
.evaluation-form .rating label { font-size: 26px; color: #cbd5e1; cursor: pointer; transition: all 0.2s; }
.evaluation-form .rating label:before { content: '★'; }
.evaluation-form .rating input:checked ~ label,
.evaluation-form .rating label:hover,
.evaluation-form .rating label:hover ~ label { color: gold; }

/* Progress Bar */
.evaluation-form .progress-bar { width: 100%; height: 8px; background-color: #e0e7ff; border-radius: 4px; margin-top: 8px; overflow: hidden; }
.evaluation-form .progress-fill { height: 100%; background: linear-gradient(90deg, #6366f1, #a855f7); border-radius: 4px; width: 0%; transition: width 0.3s ease; }

@media (max-width: 768px) {
    .evaluation-form form { padding: 25px; }
    .evaluation-form .grid { grid-template-columns: 1fr; }
    .evaluation-form .section-header { flex-direction: column; align-items: flex-start; gap: 10px; }
}
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Bitmax\OFFICE_CRM\resources\views/admin/edit-evaluation-report.blade.php ENDPATH**/ ?>