

<?php $__env->startSection('page-title', 'Leave Requests Management'); ?>
<?php $__env->startSection('page-description', 'Manage employee leave requests'); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-3 d-flex justify-content-between align-items-center">
    <h5>Leave Requests</h5>
    <a href="<?php echo e(route('admin.leave-requests.create')); ?>" class="btn btn-primary">Create Leave Request</a>
</div>

<?php if(session('success')): ?>
    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
<?php endif; ?>

<?php if(session('error')): ?>
    <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
<?php endif; ?>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped table-bordered">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Employee</th>
                        <th>Leave Type</th>
                        <th>Start Date</th>
                        <th>End Date</th>
                        <th>Days</th>
                        <th>Status</th>
                        <th>Submitted At</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $leaveRequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($request->employee->name); ?></td>
                            <td><?php echo e(ucfirst($request->leave_type)); ?></td>
                            <td><?php echo e($request->start_date ? \Carbon\Carbon::parse($request->start_date)->format('M d, Y') : '-'); ?></td>
                            <td><?php echo e($request->end_date ? \Carbon\Carbon::parse($request->end_date)->format('M d, Y') : '-'); ?></td>
                            <td><?php echo e($request->days ?? '-'); ?></td>
                            <td>
                                <span class="badge
                                    <?php if($request->status == 'approved'): ?> bg-success
                                    <?php elseif($request->status == 'rejected'): ?> bg-danger
                                    <?php elseif($request->status == 'pending'): ?> bg-warning
                                    <?php else: ?> bg-secondary
                                    <?php endif; ?>">
                                    <?php echo e(ucfirst($request->status)); ?>

                                </span>
                            </td>
                            <td><?php echo e($request->created_at->format('M d, Y H:i')); ?></td>
                            <td>
                                <div class="btn-group btn-group-sm">
                                    <a href="<?php echo e(route('admin.leave-requests.show', $request->id)); ?>" class="btn btn-info btn-sm">View</a>
                                    <?php if($request->status == 'pending'): ?>
                                        <button type="button" class="btn btn-success btn-sm" data-bs-toggle="modal" data-bs-target="#approveModal<?php echo e($request->id); ?>">Approve</button>
                                        <button type="button" class="btn btn-danger btn-sm" data-bs-toggle="modal" data-bs-target="#rejectModal<?php echo e($request->id); ?>">Reject</button>
                                    <?php endif; ?>
                                    <form action="<?php echo e(route('admin.leave-requests.destroy', $request->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Delete this leave request?')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="9" class="text-center">No leave requests found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php if($leaveRequests->hasPages()): ?>
            <div class="d-flex justify-content-center mt-3">
                <?php echo e($leaveRequests->links()); ?>

            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Approve Modals -->
<?php $__currentLoopData = $leaveRequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($request->status == 'pending'): ?>
        <!-- Approve Modal -->
        <div class="modal fade" id="approveModal<?php echo e($request->id); ?>" tabindex="-1" aria-labelledby="approveModalLabel<?php echo e($request->id); ?>" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="approveModalLabel<?php echo e($request->id); ?>">Approve Leave Request</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <form action="<?php echo e(route('admin.leave-requests.update', $request->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="modal-body">
                            <p>Are you sure you want to approve the leave request for <strong><?php echo e($request->employee->name); ?></strong>?</p>
                            <div class="mb-3">
                                <label for="remarks<?php echo e($request->id); ?>" class="form-label">Remarks (Optional)</label>
                                <textarea class="form-control" id="remarks<?php echo e($request->id); ?>" name="remarks" rows="3" placeholder="Add any remarks for approval..."></textarea>
                            </div>
                            <input type="hidden" name="status" value="approved">
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-success">Approve</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Reject Modal -->
        <div class="modal fade" id="rejectModal<?php echo e($request->id); ?>" tabindex="-1" aria-labelledby="rejectModalLabel<?php echo e($request->id); ?>" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="rejectModalLabel<?php echo e($request->id); ?>">Reject Leave Request</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <form action="<?php echo e(route('admin.leave-requests.update', $request->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="modal-body">
                            <p>Are you sure you want to reject the leave request for <strong><?php echo e($request->employee->name); ?></strong>?</p>
                            <div class="mb-3">
                                <label for="remarks<?php echo e($request->id); ?>" class="form-label">Remarks (Required)</label>
                                <textarea class="form-control" id="remarks<?php echo e($request->id); ?>" name="remarks" rows="3" placeholder="Please provide a reason for rejection..." required></textarea>
                            </div>
                            <input type="hidden" name="status" value="rejected">
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-danger">Reject</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Bitmax\OFFICE_CRM\resources\views/admin/leave-requests/index.blade.php ENDPATH**/ ?>