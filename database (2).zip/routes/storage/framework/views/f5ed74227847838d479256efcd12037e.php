

<?php $__env->startSection('page-title', 'Edit Attendance'); ?>
<?php $__env->startSection('page-description', 'Update attendance record details'); ?>

<?php $__env->startSection('content'); ?>
<?php if(session('success')): ?>
    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
<?php endif; ?>

<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul class="mb-0">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<div class="row">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Edit Attendance Record</h5>
            </div>
            <div class="card-body">
                <form method="POST" action="<?php echo e(route('attendance.update', $attendance->id)); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="employee_id" class="form-label">Employee <span class="text-danger">*</span></label>
                            <select name="employee_id" id="employee_id" class="form-select" required>
                                <option value="">Select Employee</option>
                                <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($employee->id); ?>" <?php echo e($attendance->employee_id == $employee->id ? 'selected' : ''); ?>>
                                        <?php echo e($employee->name); ?> (<?php echo e($employee->employee_code); ?>)
                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label for="date" class="form-label">Date <span class="text-danger">*</span></label>
                            <input type="date" name="date" id="date" class="form-control" value="<?php echo e($attendance->date->format('Y-m-d')); ?>" required>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="status" class="form-label">Status <span class="text-danger">*</span></label>
                            <select name="status" id="status" class="form-select" required>
                                <option value="Present" <?php echo e($attendance->status == 'Present' ? 'selected' : ''); ?>>Present</option>
                                <option value="Absent" <?php echo e($attendance->status == 'Absent' ? 'selected' : ''); ?>>Absent</option>
                                <option value="Leave" <?php echo e($attendance->status == 'Leave' ? 'selected' : ''); ?>>Leave</option>
                                <option value="Half Day" <?php echo e($attendance->status == 'Half Day' ? 'selected' : ''); ?>>Half Day</option>
                                <option value="Holiday" <?php echo e($attendance->status == 'Holiday' ? 'selected' : ''); ?>>Holiday</option>
                                <option value="NCNS" <?php echo e($attendance->status == 'NCNS' ? 'selected' : ''); ?>>NCNS</option>
                                <option value="LWP" <?php echo e($attendance->status == 'LWP' ? 'selected' : ''); ?>>LWP</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label for="marked_time" class="form-label">Marked Time <span class="text-danger">*</span></label>
                            <input type="time" name="marked_time" id="marked_time" class="form-control" value="<?php echo e($attendance->updated_at->setTimezone('Asia/Kolkata')->format('H:i')); ?>" required>
                            <small class="form-text text-muted">Time when attendance was marked</small>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-12">
                            <label for="remarks" class="form-label">Remarks</label>
                            <textarea name="remarks" id="remarks" class="form-control" rows="3" placeholder="Optional remarks..."><?php echo e($attendance->remarks); ?></textarea>
                        </div>
                    </div>

                    <div class="d-flex gap-2">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> Update Attendance
                        </button>
                        <a href="<?php echo e(route('attendance.index')); ?>" class="btn btn-secondary">
                            <i class="fas fa-arrow-left"></i> Back to List
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card">
            <div class="card-header">
                <h6 class="mb-0">Attendance Information</h6>
            </div>
            <div class="card-body">
                <div class="mb-3">
                    <strong>Employee:</strong><br>
                    <?php echo e($attendance->employee->name); ?>

                </div>
                <div class="mb-3">
                    <strong>Employee Code:</strong><br>
                    <?php echo e($attendance->employee->employee_code); ?>

                </div>
                <div class="mb-3">
                    <strong>Current Status:</strong><br>
                    <span class="badge
                        <?php if($attendance->status == 'Present'): ?> bg-success
                        <?php elseif($attendance->status == 'Absent'): ?> bg-danger
                        <?php elseif($attendance->status == 'Leave'): ?> bg-warning
                        <?php elseif($attendance->status == 'Half Day'): ?> bg-info
                        <?php elseif($attendance->status == 'Holiday'): ?> bg-primary
                        <?php endif; ?>">
                        <?php echo e($attendance->status); ?>

                    </span>
                </div>
                <div class="mb-3">
                    <strong>Date:</strong><br>
                    <?php echo e($attendance->date->format('F j, Y')); ?>

                </div>
                <div class="mb-3">
                    <strong>Created:</strong><br>
                    <?php echo e($attendance->created_at->format('M j, Y g:i A')); ?>

                </div>
                <div class="mb-3">
                    <strong>Last Updated:</strong><br>
                    <?php echo e($attendance->updated_at->format('M j, Y g:i A')); ?>

                </div>
                <?php if($attendance->remarks): ?>
                    <div class="mb-3">
                        <strong>Remarks:</strong><br>
                        <em><?php echo e($attendance->remarks); ?></em>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="card mt-3">
            <div class="card-header">
                <h6 class="mb-0">Quick Actions</h6>
            </div>
            <div class="card-body">
                <div class="d-grid gap-2">
                    <a href="<?php echo e(route('attendance.show', $attendance->id)); ?>" class="btn btn-outline-info btn-sm">
                        <i class="fas fa-eye"></i> View Details
                    </a>
                    <form method="POST" action="<?php echo e(route('attendance.destroy', $attendance->id)); ?>" onsubmit="return confirm('Are you sure you want to delete this attendance record?');" style="display: inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-outline-danger btn-sm w-100">
                            <i class="fas fa-trash"></i> Delete Record
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Bitmax\OFFICE_CRM\resources\views/admin/attendance/edit.blade.php ENDPATH**/ ?>