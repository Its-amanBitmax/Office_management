

<?php $__env->startSection('title', 'All Notifications'); ?>

<?php $__env->startSection('page-title', 'All Notifications'); ?>
<?php $__env->startSection('page-description', 'Your recent notifications'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <?php if($notifications->count()): ?>
    <div class="d-flex justify-content-end mb-3">
        <button class="btn btn-sm btn-primary" onclick="markAllAsRead()">
            <i class="fas fa-check-double"></i> Mark All as Read
        </button>
    </div>
<?php endif; ?>

    <div class="row">
        <div class="col-12">
            

            <?php if($notifications->count()): ?>
                <div class="list-group">

                    <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="list-group-item d-flex justify-content-between align-items-start"
                             style="<?php echo e($notification->is_read ? '' : 'background:#f8f9fa;'); ?>"
                             id="notification-<?php echo e($notification->id); ?>">

                            <div class="me-3">
                                <strong><?php echo e($notification->title); ?></strong>
                                <div style="font-size:0.95em;">
                                    <?php echo e($notification->message); ?>

                                </div>
                            </div>

                            <div class="text-end">
                                <div style="font-size:0.85em; color:#888;">
                                    <?php echo e($notification->created_at->diffForHumans()); ?>

                                </div>

                                <button class="btn btn-sm btn-danger mt-1"
                                    onclick="deleteNotification(<?php echo e($notification->id); ?>)">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </div>

                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>

                <div class="mt-3">
                    <?php echo e($notifications->links()); ?>

                </div>
            <?php else: ?>
                <div class="alert alert-info">
                    No notifications found.
                </div>
            <?php endif; ?>

        </div>
    </div>
</div>
<script>
window.deleteNotification = function(id) {

    if (!confirm('Are you sure you want to delete this notification?')) {
        return;
    }

    fetch(`/admin/notifications/${id}`, {
        method: 'DELETE',
        headers: {
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
            'Accept': 'application/json'
        }
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            document.getElementById(`notification-${id}`).remove();
        } else {
            alert('Unable to delete notification');
        }
    })
    .catch(err => console.error(err));
};
</script>
<script>
function markAllAsRead() {
    if (!confirm('Mark all notifications as read?')) {
        return;
    }

    fetch("<?php echo e(route('admin.notifications.markAllRead')); ?>", {
        method: 'POST',
        headers: {
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
            'Accept': 'application/json'
        }
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {

            // ✅ UI update without refresh
            document.querySelectorAll('.list-group-item').forEach(el => {
                el.style.background = 'transparent';
            });

            // ✅ Header count reset
            const countEl = document.getElementById('admin-notification-count');
            if (countEl) countEl.style.display = 'none';

        }
    });
}
</script>
<script src="https://cdn.tailwindcss.com"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Bitmax\OFFICE_CRM\resources\views/admin/notifications/index.blade.php ENDPATH**/ ?>