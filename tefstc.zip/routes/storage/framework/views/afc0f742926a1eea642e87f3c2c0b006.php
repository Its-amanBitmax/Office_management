    

    <?php $__env->startSection('page-title', 'Monthly Attendance'); ?>
    <?php $__env->startSection('page-description', 'View attendance for selected employee and month'); ?>

    <?php $__env->startSection('content'); ?>
    <div class="mb-3">
        <form method="GET" action="<?php echo e(route('attendance.showMonthly')); ?>" class="row g-3 align-items-center">
            <div class="col-auto">
                <label for="employee_id" class="form-label">Select Employee:</label>
                <select name="employee_id" id="employee_id" class="form-select" required>
                    <option value="">-- Select Employee --</option>
                    <option value="all" <?php echo e((isset($selectedEmployee) && $selectedEmployee == 'all') ? 'selected' : ''); ?>>All Employees</option>
                    <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($emp->id); ?>" <?php echo e((isset($selectedEmployee) && is_object($selectedEmployee) && $selectedEmployee->id == $emp->id) ? 'selected' : ''); ?>>
                            <?php echo e($emp->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-auto">
                <label for="month" class="form-label">Select Month:</label>
                <input type="month" name="month" id="month" class="form-control" value="<?php echo e($month ?? \Carbon\Carbon::now()->format('Y-m')); ?>" required>
            </div>
            <div class="col-auto align-self-end">
                <button type="submit" class="btn btn-primary">View Attendance</button>
            </div>
            <?php if((isset($employee) && isset($month)) || (isset($selectedEmployee) && $selectedEmployee == 'all' && isset($month))): ?>
            <div class="col-auto align-self-end">
                <?php if(isset($selectedEmployee) && $selectedEmployee == 'all'): ?>
                    <a href="<?php echo e(route('attendance.exportMonthly', ['employee_id' => 'all', 'month' => $month])); ?>" class="btn btn-success">Export All Employees Excel</a>
                <?php else: ?>
                    <a href="<?php echo e(route('attendance.exportMonthly', ['employee_id' => $employee->id, 'month' => $month])); ?>" class="btn btn-success">Export Monthly Excel</a>
                <?php endif; ?>
            </div>
            <?php endif; ?>
        </form>
    </div>

    <?php if(isset($employeeSummaries)): ?>
        <h5>All Employees Day-wise Attendance - <?php echo e(\Carbon\Carbon::createFromFormat('Y-m', $month)->format('F Y')); ?></h5>

        <?php
            $date = \Carbon\Carbon::createFromFormat('Y-m', $month);
            $daysInMonth = $date->daysInMonth;
            $allAttendances = $attendances;
        ?>

        <div class="table-responsive">
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th rowspan="2" class="align-middle">Employee Name</th>
                        <?php for($day = 1; $day <= $daysInMonth; $day++): ?>
                            <?php
                                $currentDate = \Carbon\Carbon::create($date->year, $date->month, $day);
                            ?>
                            <th class="text-center"><?php echo e($day); ?><br><small><?php echo e($currentDate->format('D')); ?></small></th>
                        <?php endfor; ?>
                        <th rowspan="2" class="align-middle">Total<br>Days</th>
                        <th rowspan="2" class="align-middle">P</th>
                        <th rowspan="2" class="align-middle">A</th>
                        <th rowspan="2" class="align-middle">L</th>
                        <th rowspan="2" class="align-middle">HD</th>
                        <th rowspan="2" class="align-middle">H</th>
                        <th rowspan="2" class="align-middle">NCNS</th>
                        <th rowspan="2" class="align-middle">LWP</th>
                        <th rowspan="2" class="align-middle">Total Salary</th>
                    </tr>
                    <tr>
                        <?php for($day = 1; $day <= $daysInMonth; $day++): ?>
                            <?php
                                $currentDate = \Carbon\Carbon::create($date->year, $date->month, $day);
                            ?>
                            <th class="text-center"><?php echo e($currentDate->format('d')); ?></th>
                        <?php endfor; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $employeeSummaries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employeeId => $summary): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="fw-bold"><?php echo e($summary['employee']->name); ?></td>
                            <?php for($day = 1; $day <= $daysInMonth; $day++): ?>
                                <?php
                                    $currentDate = \Carbon\Carbon::create($date->year, $date->month, $day)->format('Y-m-d');
                                    $attendanceCollection = $allAttendances->get($employeeId, collect())->get($currentDate);
                                    $attendance = $attendanceCollection ? $attendanceCollection->first() : null;
                                ?>
                                <td class="text-center">
                                    <?php if($attendance): ?>
                                        <?php if($attendance->status == 'Present'): ?>
                                            <span class="badge bg-success">P</span>
                                        <?php elseif($attendance->status == 'Absent'): ?>
                                            <span class="badge bg-danger">A</span>
                                        <?php elseif($attendance->status == 'Leave'): ?>
                                            <span class="badge bg-warning text-dark">L</span>
                                        <?php elseif($attendance->status == 'Half Day'): ?>
                                            <span class="badge bg-info text-dark">HD</span>
                                        <?php elseif($attendance->status == 'Holiday'): ?>
                                            <span class="badge bg-primary">H</span>
                                        <?php elseif($attendance->status == 'NCNS'): ?>
                                            <span class="badge bg-danger">NCNS</span>
                                        <?php elseif($attendance->status == 'LWP'): ?>
                                            <span class="badge bg-warning text-dark">LWP</span>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <span class="badge bg-secondary">NM</span>
                                    <?php endif; ?>
                                </td>
                            <?php endfor; ?>
                            <td class="text-center fw-bold"><?php echo e($summary['total_days']); ?></td>
                            <td class="text-center"><span class="badge bg-success"><?php echo e($summary['present']); ?></span></td>
                            <td class="text-center"><span class="badge bg-danger"><?php echo e($summary['absent']); ?></span></td>
                            <td class="text-center"><span class="badge bg-warning text-dark"><?php echo e($summary['leave']); ?></span></td>
                            <td class="text-center"><span class="badge bg-info text-dark"><?php echo e($summary['half_day']); ?></span></td>
                            <td class="text-center"><span class="badge bg-primary"><?php echo e($summary['holiday']); ?></span></td>
                            <td class="text-center"><span class="badge bg-danger"><?php echo e($summary['ncns']); ?></span></td>
                            <td class="text-center"><span class="badge bg-warning text-dark"><?php echo e($summary['lwp']); ?></span></td>
                            <td class="text-center fw-bold text-success">₹<?php echo e(number_format($summary['total_salary'], 2)); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    <?php elseif(isset($monthlyData) && isset($summary)): ?>
        <h5>Attendance for <?php echo e($employee->name); ?> - <?php echo e(\Carbon\Carbon::createFromFormat('Y-m', $month)->format('F Y')); ?></h5>

        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Day</th>
                    <th>Status</th>
                    <th>Marked At</th>
                    <th>Remarks</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $monthlyData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dayData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($dayData['date']); ?></td>
                        <td><?php echo e($dayData['day_name']); ?></td>
                        <td>
                            <?php if($dayData['status'] == 'Present'): ?>
                                <span class="badge bg-success">P</span>
                            <?php elseif($dayData['status'] == 'Absent'): ?>
                                <span class="badge bg-danger">A</span>
                            <?php elseif($dayData['status'] == 'Leave'): ?>
                                <span class="badge bg-warning text-dark">L</span>
                            <?php elseif($dayData['status'] == 'Half Day'): ?>
                                <span class="badge bg-info text-dark">HD</span>
                            <?php elseif($dayData['status'] == 'Holiday'): ?>
                                <span class="badge bg-primary">H</span>
                            <?php elseif($dayData['status'] == 'NCNS'): ?>
                                <span class="badge bg-danger">NCNS</span>
                            <?php elseif($dayData['status'] == 'LWP'): ?>
                                <span class="badge bg-warning text-dark">LWP</span>
                            <?php else: ?>
                                <span class="badge bg-secondary">NM</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($dayData['marked_at'] ?? '-'); ?></td>
                        <td><?php echo e($dayData['remarks'] ?? '-'); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tfoot>
                <tr>
                    <th colspan="2">Total Days: <?php echo e($summary['total_days']); ?></th>
                    <th>
                        P: <?php echo e($summary['present']); ?> |
                        A: <?php echo e($summary['absent']); ?> |
                        L: <?php echo e($summary['leave']); ?> |
                        HD: <?php echo e($summary['half_day']); ?> |
                        H: <?php echo e($summary['holiday']); ?> |
                        NCNS: <?php echo e($summary['ncns']); ?> |
                        LWP: <?php echo e($summary['lwp']); ?>

                    </th>
                    <th colspan="2"></th>
                </tr>
            </tfoot>
        </table>
    <?php endif; ?>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Bitmax\OFFICE_CRM\resources\views/admin/attendance/monthly.blade.php ENDPATH**/ ?>