

<?php $__env->startSection('title', 'Notifications'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <h2>Notifications</h2>
    <p>Your recent notifications</p>
</div>

<div class="card">
    <div class="card-body">

        <?php $__empty_1 = true; $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="p-3 mb-2 border rounded <?php echo e($notification->is_read ? '' : 'bg-light'); ?>">
                <strong><?php echo e($notification->title); ?></strong>
                <p class="mb-1"><?php echo e($notification->message); ?></p>
                <small class="text-muted">
                    <?php echo e($notification->created_at->diffForHumans()); ?>

                </small>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="text-center text-muted mb-0">
                No notifications found
            </p>
        <?php endif; ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.employee', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Bitmax\OFFICE_CRM\resources\views/employee/notifications/index.blade.php ENDPATH**/ ?>