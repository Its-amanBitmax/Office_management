<?php $__env->startSection('page-title', 'Manage Sub-Admins'); ?>
<?php $__env->startSection('page-description', 'List of all sub-administrators'); ?>

<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2>Sub-Admins</h2>
            <p class="text-muted">Manage sub-administrators and their permissions</p>
        </div>
        <a href="<?php echo e(route('admin.sub-admins.create')); ?>" class="btn btn-primary">
            <i class="fas fa-plus"></i> Create Sub-Admin
        </a>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Permissions</th>
                            <th>Created At</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $subAdmins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subAdmin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($subAdmins->firstItem() + $loop->index); ?></td>
                                <td><?php echo e($subAdmin->name); ?></td>
                                <td><?php echo e($subAdmin->email); ?></td>
                                <td><?php echo e($subAdmin->phone ?? 'N/A'); ?></td>
                                <td>
                                    <?php if($subAdmin->permissions): ?>
                                        <span class="badge bg-info"><?php echo e(count($subAdmin->permissions)); ?> modules</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary">No permissions</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($subAdmin->created_at ? $subAdmin->created_at->format('M d, Y') : 'N/A'); ?></td>
                                <td>
                                    <div class="btn-group" role="group">
                                        <a href="<?php echo e(route('admin.sub-admins.show', $subAdmin->id)); ?>" class="btn btn-sm btn-outline-info">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <a href="<?php echo e(route('admin.sub-admins.edit', $subAdmin->id)); ?>" class="btn btn-sm btn-outline-warning">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <form action="<?php echo e(route('admin.sub-admins.destroy', $subAdmin->id)); ?>" method="POST" style="display: inline;">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-sm btn-outline-danger" onclick="return confirm('Are you sure you want to delete this sub-admin?')">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="7" class="text-center py-4">
                                    <div class="text-muted">
                                        <i class="fas fa-users fa-3x mb-3"></i>
                                        <p>No sub-admins found.</p>
                                        <a href="<?php echo e(route('admin.sub-admins.create')); ?>" class="btn btn-primary">Create First Sub-Admin</a>
                                    </div>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <?php if($subAdmins->hasPages()): ?>
                <div class="d-flex justify-content-center">
                    <?php echo e($subAdmins->links()); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Bitmax\OFFICE_CRM\resources\views/admin/sub-admins/index.blade.php ENDPATH**/ ?>