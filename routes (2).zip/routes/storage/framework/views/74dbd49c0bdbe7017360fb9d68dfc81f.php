

<?php $__env->startSection('page-title', 'My Profile'); ?>
<?php $__env->startSection('page-description', 'View and update your profile information'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-4">
        <div class="profile-card" style="background: white; padding: 2rem; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.05); text-align: center;">
            <div class="avatar" style="width: 100px; height: 100px; border-radius: 50%; margin: 0 auto 1rem; overflow: hidden;">
                <?php if($admin->profile_image): ?>
                    <img src="<?php echo e(asset('storage/profile_images/' . $admin->profile_image)); ?>" alt="Profile Image" style="width: 100%; height: 100%; object-fit: cover;">
                <?php else: ?>
                    <div style="width: 100%; height: 100%; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); display: flex; align-items: center; justify-content: center; color: white; font-weight: bold; font-size: 2rem;">
                        <?php echo e(strtoupper(substr($admin->name, 0, 1))); ?>

                    </div>
                <?php endif; ?>
            </div>
            <h4 style="margin: 0 0 0.5rem 0; color: #333;"><?php echo e($admin->name); ?></h4>
            <p style="margin: 0; color: #666; font-size: 0.9rem;">Administrator</p>
            <div style="margin-top: 1rem;">
                <span style="background: #28a745; color: white; padding: 0.25rem 0.75rem; border-radius: 20px; font-size: 0.8rem;">Active</span>
            </div>
        </div>

            <div class="quick-stats" style="background: white; padding: 1.5rem; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.05); margin-top: 1rem;">
                <h5 style="color: #333; margin-bottom: 1rem;">Quick Stats</h5>
                <div style="display: flex; flex-direction: column; gap: 1rem;">
                    <div style="display: flex; justify-content: space-between; align-items: center;">
                        <span style="color: #666;">Last Login</span>
                        <span style="font-weight: bold; color: #333;"><?php echo e($admin->updated_at ? $admin->updated_at->format('M d, Y') : 'N/A'); ?></span>
                    </div>
                    <div style="display: flex; justify-content: space-between; align-items: center;">
                        <span style="color: #666;">Account Created</span>
                        <span style="font-weight: bold; color: #333;"><?php echo e($admin->created_at ? $admin->created_at->format('M d, Y') : 'N/A'); ?></span>
                    </div>
                    <div style="display: flex; justify-content: space-between; align-items: center;">
                        <span style="color: #666;">Profile Updates</span>
                        <span style="font-weight: bold; color: #333;">3</span>
                    </div>
                </div>
            </div>
    </div>

    <div class="col-md-8">
        <div class="profile-form" style="background: white; padding: 2rem; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.05);">
            <h4 style="color: #333; margin-bottom: 1.5rem; border-bottom: 2px solid #007bff; padding-bottom: 0.5rem;">Edit Profile</h4>

            <?php if(session('success')): ?>
                <div style="background: #d4edda; color: #155724; padding: 1rem; border-radius: 4px; margin-bottom: 1rem; border: 1px solid #c3e6cb;">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <?php if($errors->any()): ?>
                <div style="background: #f8d7da; color: #721c24; padding: 1rem; border-radius: 4px; margin-bottom: 1rem; border: 1px solid #f5c6cb;">
                    <ul style="margin: 0; padding-left: 1rem;">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <form method="POST" action="<?php echo e(route('admin.profile.update')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="mb-3">
                    <label for="name" class="form-label">Full Name</label>
                    <input type="text" id="name" name="name" value="<?php echo e(old('name', $admin->name)); ?>" required class="form-control">
                </div>

                <div class="mb-3">
                    <label for="email" class="form-label">Email Address</label>
                    <input type="email" id="email" name="email" value="<?php echo e(old('email', $admin->email)); ?>" required class="form-control">
                </div>

                <div class="mb-3">
                    <label for="phone" class="form-label">Phone Number (Optional)</label>
                    <input type="tel" id="phone" name="phone" value="<?php echo e(old('phone', $admin->phone ?? '')); ?>" class="form-control">
                </div>

                <div class="mb-3">
                    <label for="bio" class="form-label">Bio (Optional)</label>
                    <textarea id="bio" name="bio" rows="4" class="form-control"><?php echo e(old('bio', $admin->bio ?? '')); ?></textarea>
                </div>

                <div class="mb-3">
                    <label for="company_name" class="form-label">Company Name (Optional)</label>
                    <input type="text" id="company_name" name="company_name" value="<?php echo e(old('company_name', $admin->company_name ?? '')); ?>" class="form-control">
                </div>

                <div class="mb-3">
                    <label for="company_logo" class="form-label">Company Logo (Optional)</label>
                    <input type="file" id="company_logo" name="company_logo" accept="image/*" class="form-control">
                    <small class="form-text text-muted">Accepted formats: JPEG, PNG, JPG, GIF. Max size: 2MB</small>
                </div>

                <div class="mb-3">
                    <label for="profile_image" class="form-label">Profile Image (Optional)</label>
                    <input type="file" id="profile_image" name="profile_image" accept="image/*" class="form-control">
                    <small class="form-text text-muted">Accepted formats: JPEG, PNG, JPG, GIF. Max size: 2MB</small>
                </div>

            
            <div class="d-flex gap-3">
                <button type="submit" class="btn btn-primary flex-grow-1">Update Profile</button>
                <a href="<?php echo e(route('admin.dashboard')); ?>" class="btn btn-secondary flex-grow-1 text-center">Cancel</a>
            </div>
        </form>
        </div>
    </div>

    <div class="col-md-4" style="margin-top: -24.5rem">
        <div class="password-section" style="background: white; padding: 1.5rem 2rem 2rem 2rem; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.05);">
            <h4 style="color: #333; margin-bottom: 1rem; border-bottom: 2px solid #dc3545; padding-bottom: 0.5rem;">Change Password</h4>

            <form method="POST" action="<?php echo e(route('admin.password.update')); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="mb-3">
                    <label for="current_password" class="form-label">Current Password</label>
                    <input type="password" id="current_password" name="current_password" required class="form-control">
                </div>

                <div class="mb-3">
                    <label for="password" class="form-label">New Password</label>
                    <input type="password" id="password" name="password" required class="form-control">
                </div>

                <div class="mb-1">
                    <label for="password_confirmation" class="form-label">Confirm New Password</label>
                    <input type="password" id="password_confirmation" name="password_confirmation" required class="form-control">
                </div>

                <button type="submit" class="btn btn-danger w-100">Update Password</button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
</result>
</attempt_completion>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Bitmax\OFFICE_CRM\resources\views/admin/profile.blade.php ENDPATH**/ ?>