

<?php $__env->startSection('page-title', 'Interview Details'); ?>
<?php $__env->startSection('page-description', 'View interview information'); ?>

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-md-10">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0">Interview Details</h5>
                <div>
                    <a href="<?php echo e(route('admin.interviews.edit', $interview)); ?>" class="btn btn-warning btn-sm">Edit</a>
                    <a href="<?php echo e(route('admin.interviews.index')); ?>" class="btn btn-secondary btn-sm">Back to List</a>
                </div>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <h6 class="text-muted">Candidate Information</h6>
                        <table class="table table-sm">
                            <tr>
                                <th width="40%">Name:</th>
                                <td><?php echo e($interview->candidate_name); ?></td>
                            </tr>
                            <tr>
                                <th>Email:</th>
                                <td><?php echo e($interview->candidate_email); ?></td>
                            </tr>
                            <tr>
                                <th>Phone:</th>
                                <td><?php echo e($interview->candidate_phone ?: 'N/A'); ?></td>
                            </tr>
                            <tr>
                                <th>Profile:</th>
                                <td><?php echo e($interview->candidate_profile ?: 'N/A'); ?></td>
                            </tr>
                            <tr>
                                <th>Experience:</th>
                                <td><?php echo e($interview->candidate_experience ?: 'N/A'); ?></td>
                            </tr>
                        </table>
                    </div>

                    <div class="col-md-6">
                        <h6 class="text-muted">Interview Schedule</h6>
                        <table class="table table-sm">
                            <tr>
                                <th width="40%">Date:</th>
                                <td><?php echo e($interview->date->format('M d, Y')); ?></td>
                            </tr>
                            <tr>
                                <th>Time:</th>
                                <td><?php echo e($interview->time->format('H:i')); ?></td>
                            </tr>
                            <tr>
                                <th>Scheduled At:</th>
                                <td><?php echo e($interview->scheduled_at->format('M d, Y H:i')); ?></td>
                            </tr>
                            <tr>
                                <th>Status:</th>
                                <td>
                                    <span class="badge
                                        <?php if($interview->status == 'scheduled'): ?> bg-primary
                                        <?php elseif($interview->status == 'completed'): ?> bg-success
                                        <?php elseif($interview->status == 'cancelled'): ?> bg-danger
                                        <?php elseif($interview->status == 'rescheduled'): ?> bg-warning
                                        <?php endif; ?>">
                                        <?php echo e(ucfirst($interview->status)); ?>

                                    </span>
                                </td>
                            </tr>
                            <tr>
    <th>Link Status:</th>
    <td>
        <span class="badge <?php echo e($interview->link_status == '1' ? 'bg-success' : 'bg-danger'); ?>">
            <?php echo e($interview->link_status == '1' ? 'Active' : 'Inactive'); ?>

        </span>

        <form action="<?php echo e(route('interviews.toggleLinkStatus', $interview->id)); ?>"
              method="POST"
              class="d-inline ms-2">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <button type="submit"
                class="btn btn-sm <?php echo e($interview->link_status == '1' ? 'btn-outline-danger' : 'btn-outline-success'); ?>">
                <?php echo e($interview->link_status == '1' ? 'Disable' : 'Enable'); ?>

            </button>
        </form>
    </td>
</tr>

                        </table>
                    </div>
                </div>

                <div class="row mt-4">
                    <div class="col-md-6">
                        <h6 class="text-muted">Interview Links & IDs</h6>
                        <table class="table table-sm">
                            <tr>
                                <th>Interview Code:</th>
                                <td><?php echo e($interview->interview_code ?: 'N/A'); ?></td>
                            </tr>
                            <tr>
                                <th>Interview Link:</th>
                              <td>
    <?php if($interview->link_status == '1'): ?>
        <a href="<?php echo e(route('interview.link', $interview->unique_link)); ?>"
           target="_blank"
           class="btn btn-sm btn-primary">
            <i class="fas fa-external-link-alt"></i> Open Interview Link
        </a>

        <button class="btn btn-sm btn-outline-secondary ms-2"
                onclick="copyToClipboard('<?php echo e(route('interview.link', $interview->unique_link)); ?>')">
            <i class="fas fa-copy"></i> Copy Link
        </button>
    <?php else: ?>
        <button class="btn btn-sm btn-secondary" disabled>
            <i class="fas fa-lock"></i> Link Disabled
        </button>

        <button class="btn btn-sm btn-outline-secondary ms-2" disabled>
            <i class="fas fa-copy"></i> Copy Disabled
        </button>
    <?php endif; ?>
</td>

                            </tr>
                            <tr>
                                <th>Interview Room:</th>
                                <td>
                                    <a href="<?php echo e(route('admin.interviews.room', $interview)); ?>" target="_blank" class="btn btn-sm btn-success">
                                        <i class="fas fa-video"></i> Enter Interview Room
                                    </a>
                                </td>
                            </tr>
                            <tr>
                                <th>Results:</th>
                                <td>
                                    <?php if($interview->results): ?>
                                        <span class="badge
                                            <?php if($interview->results == 'selected'): ?> bg-success
                                            <?php elseif($interview->results == 'rejected'): ?> bg-danger
                                            <?php elseif($interview->results == 'pending'): ?> bg-warning
                                            <?php endif; ?>">
                                            <?php echo e(ucfirst($interview->results)); ?>

                                        </span>
                                    <?php else: ?>
                                        N/A
                                    <?php endif; ?>
                                </td>
                            </tr>
                        </table>
                    </div>

                    <div class="col-md-6">
                        <h6 class="text-muted">Documents</h6>
                        <?php if($interview->candidate_resume_path): ?>
                            <table class="table table-sm">
                                <tr>
                                    <th width="40%">Candidate Resume:</th>
                                    <td>
                                        <a href="<?php echo e(Storage::url($interview->candidate_resume_path)); ?>" target="_blank" class="btn btn-sm btn-info">
                                            <i class="fas fa-download"></i> Download
                                        </a>
                                    </td>
                                </tr>
                            </table>
                        <?php else: ?>
                            <p class="text-muted">No candidate resume uploaded.</p>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="row mt-4">
                    <div class="col-12">
                        <h6 class="text-muted">Timestamps</h6>
                        <table class="table table-sm">
                            <tr>
                                <th width="20%">Created At:</th>
                                <td><?php echo e($interview->created_at->format('M d, Y H:i')); ?></td>
                            </tr>
                            <tr>
                                <th>Updated At:</th>
                                <td><?php echo e($interview->updated_at->format('M d, Y H:i')); ?></td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function copyToClipboard(text) {
    const button = event.target;

    // Try modern clipboard API first
    if (navigator.clipboard && window.isSecureContext) {
        navigator.clipboard.writeText(text).then(function() {
            showSuccess(button);
        }).catch(function(err) {
            console.error('Failed to copy: ', err);
            fallbackCopyTextToClipboard(text, button);
        });
    } else {
        // Fallback for older browsers or non-HTTPS
        fallbackCopyTextToClipboard(text, button);
    }
}

function fallbackCopyTextToClipboard(text, button) {
    const textArea = document.createElement("textarea");
    textArea.value = text;

    // Avoid scrolling to bottom
    textArea.style.top = "0";
    textArea.style.left = "0";
    textArea.style.position = "fixed";
    textArea.style.opacity = "0";

    document.body.appendChild(textArea);
    textArea.focus();
    textArea.select();

    try {
        const successful = document.execCommand('copy');
        if (successful) {
            showSuccess(button);
        } else {
            showErrorMessage('Failed to copy link to clipboard.');
        }
    } catch (err) {
        console.error('Fallback copy failed: ', err);
        showErrorMessage('Failed to copy link to clipboard.');
    }

    document.body.removeChild(textArea);
}

function showSuccess(button) {
    // Show a temporary success message
    const originalText = button.textContent;
    button.textContent = 'Copied!';
    button.classList.remove('btn-outline-secondary');
    button.classList.add('btn-success');

    // Show success alert
    showSuccessMessage('Interview link copied to clipboard successfully!');

    setTimeout(() => {
        button.textContent = originalText;
        button.classList.remove('btn-success');
        button.classList.add('btn-outline-secondary');
    }, 2000);
}

function showSuccessMessage(message) {
    // Remove any existing alerts
    const existingAlert = document.querySelector('.alert');
    if (existingAlert) {
        existingAlert.remove();
    }

    // Create success alert
    const alertDiv = document.createElement('div');
    alertDiv.className = 'alert alert-success alert-dismissible fade show position-fixed';
    alertDiv.style.cssText = 'top: 20px; right: 20px; z-index: 9999; min-width: 300px;';
    alertDiv.innerHTML = `
        <i class="fas fa-check-circle"></i> ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;

    document.body.appendChild(alertDiv);

    // Auto remove after 3 seconds
    setTimeout(() => {
        if (alertDiv.parentNode) {
            alertDiv.remove();
        }
    }, 3000);
}

function showErrorMessage(message) {
    // Remove any existing alerts
    const existingAlert = document.querySelector('.alert');
    if (existingAlert) {
        existingAlert.remove();
    }

    // Create error alert
    const alertDiv = document.createElement('div');
    alertDiv.className = 'alert alert-danger alert-dismissible fade show position-fixed';
    alertDiv.style.cssText = 'top: 20px; right: 20px; z-index: 9999; min-width: 300px;';
    alertDiv.innerHTML = `
        <i class="fas fa-exclamation-triangle"></i> ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;

    document.body.appendChild(alertDiv);

    // Auto remove after 3 seconds
    setTimeout(() => {
        if (alertDiv.parentNode) {
            alertDiv.remove();
        }
    }, 3000);
}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Bitmax\OFFICE_CRM\resources\views/admin/interviews/show.blade.php ENDPATH**/ ?>