

<?php $__env->startSection('title', 'My Attendance'); ?>

<?php $__env->startSection('page-title', 'My Attendance'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <!-- Attendance Sidebar -->
    <div class="col-md-3">
        <div class="card">
            <div class="card-header">
                <h6 class="mb-0">Leave Management</h6>
            </div>
            <div class="card-body">
                <div class="d-grid gap-2">
                    <a href="<?php echo e(route('employee.leave-requests.create')); ?>" class="btn btn-primary btn-sm">
                        <i class="fas fa-plus me-2"></i>Request Leave
                    </a>
                    <a href="<?php echo e(route('employee.leave-requests.index')); ?>" class="btn btn-outline-primary btn-sm">
                        <i class="fas fa-list me-2"></i>View My Requests
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Main Content -->
    <div class="col-md-9">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Select Month to View Attendance</h5>
            </div>
            <div class="card-body">
                <form method="GET" action="<?php echo e(route('employee.attendance.show')); ?>" class="row g-3">
                    <div class="col-md-4">
                        <label for="month" class="form-label">Select Month</label>
                        <input type="month" class="form-control" id="month" name="month" value="<?php echo e($month ?? now()->format('Y-m')); ?>" required>
                    </div>
                    <div class="col-md-4 d-flex align-items-end">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-search me-2"></i>View Attendance
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php if(isset($summary)): ?>
<div class="row mt-4">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Attendance Summary for <?php echo e(\Carbon\Carbon::createFromFormat('Y-m', $month)->format('F Y')); ?></h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-2">
                        <div class="text-center">
                            <div class="h4 text-primary"><?php echo e($summary['total_days']); ?></div>
                            <small class="text-muted">Total Days</small>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="text-center">
                            <div class="h4 text-success"><?php echo e($summary['present']); ?></div>
                            <small class="text-muted">Present</small>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="text-center">
                            <div class="h4 text-danger"><?php echo e($summary['absent']); ?></div>
                            <small class="text-muted">Absent</small>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="text-center">
                            <div class="h4 text-warning"><?php echo e($summary['leave']); ?></div>
                            <small class="text-muted">Leave</small>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="text-center">
                            <div class="h4 text-info"><?php echo e($summary['half_day']); ?></div>
                            <small class="text-muted">Half Day</small>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="text-center">
                            <div class="h4 text-secondary"><?php echo e($summary['holiday']); ?></div>
                            <small class="text-muted">Holiday</small>
                        </div>
                    </div>
                </div>
             
            </div>
        </div>
    </div>
</div>

<div class="row mt-4">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Daily Attendance Details</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Day</th>
                                <th>Status</th>
                                <th>Marked At</th>
                                <th>Remarks</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $monthlyData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(\Carbon\Carbon::parse($data['date'])->format('d/m/Y')); ?></td>
                                <td><?php echo e($data['day_name']); ?></td>
                                <td>
                                    <?php if($data['status'] == 'Present'): ?>
                                        <span class="badge bg-success"><?php echo e($data['status']); ?></span>
                                    <?php elseif($data['status'] == 'Absent'): ?>
                                        <span class="badge bg-danger"><?php echo e($data['status']); ?></span>
                                    <?php elseif($data['status'] == 'Leave'): ?>
                                        <span class="badge bg-warning"><?php echo e($data['status']); ?></span>
                                    <?php elseif($data['status'] == 'Half Day'): ?>
                                        <span class="badge bg-info"><?php echo e($data['status']); ?></span>
                                    <?php elseif($data['status'] == 'Holiday'): ?>
                                        <span class="badge bg-secondary"><?php echo e($data['status']); ?></span>
                                    <?php else: ?>
                                        <span class="badge bg-light text-dark"><?php echo e($data['status']); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($data['marked_at'] ?? '-'); ?></td>
                                <td><?php echo e($data['remarks'] ?? '-'); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.employee', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Bitmax\OFFICE_CRM\resources\views/employee/attendance.blade.php ENDPATH**/ ?>